import React from 'react';
export const Nav20DataSource = {
  isScrollLink: true,
  wrapper: { className: 'header2 home-page-wrapper' },
  page: { className: 'home-page' },
  logo: {
    className: 'header2-logo',
    children:
      'https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcRiCQbsA-ScBt1SoRn-eu8CrLq3pw3EZY-yzA&s',
  },
  LinkMenu: {
    className: 'header2-menu',
    children: [
      {
        name: 'linkNav',
        to: '当前页面 ID 地址，参考如上',
        children: 'introduction',
        className: 'menu-item',
      },
      {
        name: 'linkNav~m167r42mhxs',
        to: '当前页面 ID 地址，参考如上',
        children: 'support',
        className: 'menu-item',
      },
      {
        name: 'linkNav~m167rkvmkd',
        to: '当前页面 ID 地址，参考如上',
        children: 'All about us',
        className: 'menu-item',
      },
      {
        name: 'linkNav~m167s4wda8b',
        to: '当前页面 ID 地址，参考如上',
        children: 'attention',
        className: 'menu-item',
      },
    ],
  },
  mobileMenu: { className: 'header2-mobile-menu' },
};
export const Banner01DataSource = {
  wrapper: { className: 'banner0 m1646tdjth-editor_css' },
  textWrapper: { className: 'banner0-text-wrapper m1645uoj0ue-editor_css' },
  title: {
    className: 'banner0-title m1648gno7cj-editor_css',
    children: (
      <span>
        <p>
          <b>animal abuse</b>
        </p>
      </span>
    ),
  },
  content: {
    className: 'banner0-content m164aqn7d2i-editor_css',
    children: (
      <span>
        <p>care about stray cats and stray dogs</p>
      </span>
    ),
  },
  button: {
    className: 'banner0-button',
    children: (
      <span>
        <span>
          <p>
            <br />
          </p>
        </span>
      </span>
    ),
  },
};
export const Content00DataSource = {
  wrapper: { className: 'home-page-wrapper content0-wrapper' },
  page: { className: 'home-page content0 m164f1buvuo-editor_css' },
  OverPack: { playScale: 0.3, className: '' },
  titleWrapper: {
    className: 'title-wrapper',
    children: [
      {
        name: 'title',
        children: (
          <span>
            <span>
              <span>
                <p>About us</p>
                <p>
                  <br />
                </p>
              </span>
            </span>
          </span>
        ),
      },
    ],
  },
  childWrapper: {
    className: 'content0-block-wrapper',
    children: [
      {
        name: 'block0',
        className: 'content0-block',
        md: 8,
        xs: 24,
        children: {
          className: 'content0-block-item',
          children: [
            {
              name: 'image',
              className: 'content0-block-icon',
              children:
                'https://zos.alipayobjects.com/rmsportal/WBnVOjtIlGWbzyQivuyq.png',
            },
            {
              name: 'title',
              className: 'content0-block-title',
              children: (
                <span>
                  <p>Donation</p>
                </span>
              ),
            },
            {
              name: 'content',
              children: (
                <span>
                  <p>
                    Do not take any money that does not belong to us, and the
                    results after each donation are transparent, every one can
                    see.
                  </p>
                </span>
              ),
            },
          ],
        },
      },
      {
        name: 'block1',
        className: 'content0-block',
        md: 8,
        xs: 24,
        children: {
          className: 'content0-block-item',
          children: [
            {
              name: 'image',
              className: 'content0-block-icon',
              children:
                'https://zos.alipayobjects.com/rmsportal/YPMsLQuCEXtuEkmXTTdk.png',
            },
            {
              name: 'title',
              className: 'content0-block-title',
              children: (
                <span>
                  <p>All for animals&nbsp;</p>
                </span>
              ),
            },
            {
              name: 'content',
              children: (
                <span>
                  <p>
                    All volunteer for cats and dogs, all non-profit.<br />
                  </p>
                </span>
              ),
            },
          ],
        },
      },
      {
        name: 'block2',
        className: 'content0-block',
        md: 8,
        xs: 24,
        children: {
          className: 'content0-block-item',
          children: [
            {
              name: 'image',
              className: 'content0-block-icon',
              children:
                'https://zos.alipayobjects.com/rmsportal/EkXWVvAaFJKCzhMmQYiX.png',
            },
            {
              name: 'title',
              className: 'content0-block-title',
              children: (
                <span>
                  <p>
                    Disclosure details<br />
                  </p>
                </span>
              ),
            },
            {
              name: 'content',
              children: (
                <span>
                  <p>
                    Feel free to contact us if you have any questions<br />
                  </p>
                </span>
              ),
            },
          ],
        },
      },
    ],
  },
};
export const Feature40DataSource = {
  wrapper: { className: 'home-page-wrapper content6-wrapper' },
  OverPack: { className: 'home-page content6' },
  textWrapper: { className: 'content6-text', xs: 24, md: 10 },
  titleWrapper: {
    className: 'title-wrapper',
    children: [
      {
        name: 'title',
        children: (
          <span>
            <p>About us</p>
          </span>
        ),
        className: 'title-h1 m166efeedne-editor_css',
      },
      {
        name: 'content',
        className: 'title-content',
        children: (
          <span>
            <p>Why i made this website?</p>
          </span>
        ),
      },
    ],
  },
  img: {
    children:
      'https://greenarea.com.lb/wp-content/uploads/2016/09/418323460_1367120473-1080x675.jpg',
    className: 'content6-img m166e0o2pi8-editor_css',
    xs: 24,
    md: 14,
  },
  block: {
    children: [
      {
        name: 'block0',
        img: {
          children:
            'https://zos.alipayobjects.com/rmsportal/NKBELAOuuKbofDD.png',
          className: 'content6-icon',
        },
        title: {
          className: 'content6-title',
          children: (
            <span>
              <p>The problem of animal abuse</p>
            </span>
          ),
        },
        content: {
          className: 'content6-content',
          children: (
            <span>
              <span>
                <p>
                  Some people like to abuse cats and dogs, and many innocent
                  animals are killed by cruel injuries because they are weaker
                  than humans. Animal abuse is not seen as a harsh thing in many
                  places, but animals are innocent and should not be killed for
                  ridiculous reasons such as sudden anger or the filth of stray
                  cats and dogs
                </p>
              </span>
            </span>
          ),
        },
      },
      {
        name: 'block1',
        img: {
          className: 'content6-icon',
          children:
            'https://zos.alipayobjects.com/rmsportal/xMSBjgxBhKfyMWX.png',
        },
        title: {
          className: 'content6-title',
          children: (
            <span>
              <p>we want more people to care about animal abuse</p>
            </span>
          ),
        },
        content: {
          className: 'content6-content',
          children: (
            <span>
              <p>
                I don't think all people will support animals and do something
                for them, this is absolutely right, but i hope people can know
                about these issues and animal abuse were getting more and more
                in China. So please care about the issue and be kind to all
                animals ❤️
              </p>
            </span>
          ),
        },
      },
      {
        name: 'block2',
        img: {
          className: 'content6-icon',
          children:
            'https://zos.alipayobjects.com/rmsportal/MNdlBNhmDBLuzqp.png',
        },
        title: {
          className: 'content6-title',
          children: (
            <span>
              <p>Trying my best to help them</p>
            </span>
          ),
        },
        content: {
          className: 'content6-content',
          children: (
            <span>
              <p>Not only i will make the&nbsp;</p>
            </span>
          ),
        },
      },
    ],
  },
};
export const Banner50DataSource = {
  wrapper: { className: 'home-page-wrapper banner5' },
  page: { className: 'home-page banner5-page' },
  childWrapper: {
    className: 'banner5-title-wrapper',
    children: [
      {
        name: 'title',
        children: (
          <span>
            <span>
              <p>Our product</p>
            </span>
          </span>
        ),
        className: 'banner5-title m16597uz3hb-editor_css',
      },
      {
        name: 'explain',
        className: 'banner5-explain',
        children: (
          <span>
            <p>Sterling silver animal necklace</p>
          </span>
        ),
      },
      {
        name: 'content',
        className: 'banner5-content',
        children: (
          <span>
            <span>
              <p>
                Each is hand-crafted from ceramic, stone clay and sterling
                silver. For every necklace purchased, puppies and kittens will
                have enough food for a week.
              </p>
            </span>
          </span>
        ),
      },
      {
        name: 'button',
        className: 'banner5-button-wrapper',
        children: {
          href: '#https://s2.loli.net/2024/09/17/Z5HPNSlzLgwUhAy.png',
          className: 'banner5-button',
          type: 'primary',
          children: (
            <span>
              <p>example</p>
            </span>
          ),
          target: '_blank',
        },
      },
    ],
  },
  image: {
    className: 'banner5-image',
    children: 'https://uc.udn.com.tw/photo/2023/08/30/0/24621843.jpg',
  },
};
export const Content130DataSource = {
  OverPack: {
    className: 'home-page-wrapper content13-wrapper',
    playScale: 0.3,
  },
  titleWrapper: {
    className: 'title-wrapper',
    children: [
      {
        name: 'image',
        children:
          'https://gw.alipayobjects.com/zos/rmsportal/PiqyziYmvbgAudYfhuBr.svg',
        className: 'title-image',
      },
      {
        name: 'title',
        children: (
          <span>
            <p>Matters need attention</p>
          </span>
        ),
        className: 'title-h1',
      },
      {
        name: 'content',
        children: (
          <span>
            <span>
              <p>
                The design and production process of the necklace is relatively
                slow and it has just started,
              </p>
              <p>
                &nbsp;pure handmade and this is an initial design, which will
                lead to a long process 💕&nbsp;
              </p>
              <p>
                We are also looking for donation organizations, if we find a
                reliable organization,&nbsp;
              </p>
              <p>
                we will send information to all donors and list details after
                donation.<br />
              </p>
            </span>
          </span>
        ),
        className: 'title-content',
      },
      {
        name: 'content2',
        children: (
          <span>
            <p>
              <br />
            </p>
          </span>
        ),
        className: 'title-content',
      },
    ],
  },
};
export const Footer00DataSource = {
  wrapper: { className: 'home-page-wrapper footer0-wrapper' },
  OverPack: { className: 'home-page footer0', playScale: 0.05 },
  copyright: {
    className: 'copyright',
    children: (
      <span>
        <span>
          <span>
            <span>
              ©2018 <a href="https://motion.ant.design">Ant Motion</a> All
              Rights Reserved&nbsp;&nbsp;
            </span>
          </span>
        </span>By Anna Zhang<span>
          <span>
            <span>&nbsp;</span>
          </span>
        </span>All for puppies and kittens<span>
          <span>
            <p>By Anna Zhang&nbsp;</p>
            <p>
              <br />
            </p>
          </span>
        </span>
      </span>
    ),
  },
};
